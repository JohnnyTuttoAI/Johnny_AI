import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import { Toaster } from 'react-hot-toast';
import { WalletProviders } from './providers/WalletProviders';
import Sidebar from './components/layout/Sidebar';
import TopBar from './components/layout/TopBar';
import MainContent from './components/layout/MainContent';
import Landing from './pages/Landing';
import ChatInterface from './components/ChatInterface';
import Docs from './pages/Docs';

function App() {
  return (
    <WalletProviders>
      <Router>
        <div className="min-h-screen bg-black text-white">
          <Sidebar />
          <TopBar />
          <MainContent>
            <Routes>
              <Route path="/" element={<Landing />} />
              <Route path="/chat" element={<ChatInterface />} />
              <Route path="/docs" element={<Docs />} />
            </Routes>
          </MainContent>
        </div>
        <Toaster position="top-right" />
      </Router>
    </WalletProviders>
  );
}

export default App;