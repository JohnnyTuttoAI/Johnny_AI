export interface AgentState {
  level: number;
  experience: number;
  lastInteraction: number;
}