import React from 'react';
import ChatInput from './ChatInput';
import MessageList from './MessageList';
import { useChat } from '../../hooks/useChat';
import GlowingCard from '../ui/GlowingCard';

export default function ChatContainer() {
  const { messages, isLoading, sendMessage } = useChat();

  return (
    <GlowingCard className="h-[calc(100vh-8rem)] flex flex-col">
      <div className="flex-1 overflow-hidden">
        <MessageList messages={messages} isLoading={isLoading} />
      </div>
      <ChatInput onSendMessage={sendMessage} isLoading={isLoading} />
    </GlowingCard>
  );
}