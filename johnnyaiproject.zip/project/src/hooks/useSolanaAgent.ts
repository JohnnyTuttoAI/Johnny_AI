import { useConnection, useWallet } from '@solana/wallet-adapter-react';
import { useState, useEffect } from 'react';
import { AgentProgram } from '../services/solana/agentKit/program';
import { AGENT_CONFIG } from '../services/solana/agentKit/constants';
import type { AgentState } from '../services/solana/agentKit/types';

export function useSolanaAgent() {
  const { connection } = useConnection();
  const { publicKey } = useWallet();
  const [agent, setAgent] = useState<AgentProgram | null>(null);
  const [state, setState] = useState<AgentState | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (!connection || !publicKey) {
      setLoading(false);
      return;
    }

    const initAgent = async () => {
      try {
        const program = new AgentProgram(connection, AGENT_CONFIG.PROGRAM_ID);
        setAgent(program);
        const agentState = await program.getAgentState();
        setState(agentState);
      } catch (err) {
        setError(err instanceof Error ? err.message : 'Failed to initialize agent');
      } finally {
        setLoading(false);
      }
    };

    initAgent();
  }, [connection, publicKey]);

  return {
    agent,
    state,
    loading,
    error,
    isReady: !!agent && !!state && !loading
  };
}