export const AGENT_CONFIG = {
  PROGRAM_ID: 'AgentKitXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX',
  NETWORK: 'mainnet-beta',
  RPC_URL: 'https://api.mainnet-beta.solana.com'
} as const;