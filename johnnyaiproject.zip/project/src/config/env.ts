interface EnvConfig {
  openai: {
    apiKey: string;
    baseUrl: string;
  };
  coingecko: {
    apiKey: string;
    baseUrl: string;
  };
  wallet: {
    projectId: string;
  };
}

function validateEnvVar(name: string, value: string | undefined): string {
  if (!value) {
    throw new Error(`Missing required environment variable: ${name}`);
  }
  return value;
}

export const config: EnvConfig = {
  openai: {
    apiKey: validateEnvVar('VITE_OPENAI_API_KEY', import.meta.env.VITE_OPENAI_API_KEY),
    baseUrl: 'https://api.openai.com/v1'
  },
  coingecko: {
    apiKey: validateEnvVar('VITE_COINGECKO_API_KEY', import.meta.env.VITE_COINGECKO_API_KEY),
    baseUrl: 'https://pro-api.coingecko.com/api/v3'
  },
  wallet: {
    projectId: validateEnvVar('VITE_WALLET_PROJECT_ID', import.meta.env.VITE_WALLET_PROJECT_ID)
  }
};