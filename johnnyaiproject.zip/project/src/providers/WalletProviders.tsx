import { WagmiProvider } from 'wagmi';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import { RainbowKitProvider, darkTheme } from '@rainbow-me/rainbowkit';
import { SolanaProvider } from './SolanaProvider';
import { walletConfig } from '../config/wallet';

const queryClient = new QueryClient();

const customTheme = darkTheme({
  accentColor: '#FF0000', // Swiss red
  accentColorForeground: 'white',
  borderRadius: 'none',
  fontStack: 'system',
  overlayBlur: 'small',
});

export function WalletProviders({ children }: { children: React.ReactNode }) {
  return (
    <WagmiProvider config={walletConfig}>
      <QueryClientProvider client={queryClient}>
        <RainbowKitProvider theme={customTheme}>
          <SolanaProvider>
            {children}
          </SolanaProvider>
        </RainbowKitProvider>
      </QueryClientProvider>
    </WagmiProvider>
  );
}