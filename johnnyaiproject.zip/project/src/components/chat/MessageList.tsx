import React from 'react';
import { ChatMessage } from '../../types';
import MessageBubble from './MessageBubble';
import LoadingIndicator from '../ui/LoadingIndicator';

interface MessageListProps {
  messages: ChatMessage[];
  isLoading: boolean;
}

export default function MessageList({ messages, isLoading }: MessageListProps) {
  return (
    <div className="flex flex-col space-y-4 p-4 overflow-y-auto">
      {messages.map((message, index) => (
        <MessageBubble key={index} message={message} />
      ))}
      {isLoading && <LoadingIndicator />}
    </div>
  );
}