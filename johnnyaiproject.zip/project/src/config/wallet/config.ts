import { getDefaultConfig } from '@rainbow-me/rainbowkit';
import { mainnet, base, optimism, arbitrum } from 'viem/chains';
import { http } from 'viem';
import { flareChain, songbirdChain } from '../networks/flare/chains';
import { config } from '../env';

export const walletConfig = getDefaultConfig({
  appName: 'JOHNNY.AI',
  projectId: config.wallet.projectId,
  chains: [
    mainnet, 
    base, 
    optimism, 
    arbitrum, 
    flareChain,
    songbirdChain
  ],
  transports: {
    [mainnet.id]: http(),
    [base.id]: http(),
    [optimism.id]: http(),
    [arbitrum.id]: http(),
    [flareChain.id]: http(),
    [songbirdChain.id]: http()
  },
  ssr: false
});