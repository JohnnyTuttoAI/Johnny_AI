import { GraphData } from './types';

export const marketData: GraphData = {
  nodes: [
    { id: "BTC", group: "major", value: 100 },
    { id: "ETH", group: "major", value: 80 },
    { id: "SOL", group: "major", value: 60 },
    { id: "USDT", group: "stable", value: 90 },
    { id: "USDC", group: "stable", value: 85 },
    { id: "BNB", group: "exchange", value: 70 },
    { id: "XRP", group: "major", value: 55 },
    { id: "ADA", group: "major", value: 50 },
    { id: "DOGE", group: "meme", value: 45 },
    { id: "SHIB", group: "meme", value: 40 }
  ],
  links: [
    { source: "BTC", target: "ETH", value: 8 },
    { source: "BTC", target: "USDT", value: 10 },
    { source: "ETH", target: "USDT", value: 9 },
    { source: "ETH", target: "USDC", value: 8 },
    { source: "SOL", target: "USDT", value: 7 },
    { source: "SOL", target: "USDC", value: 6 },
    { source: "BNB", target: "USDT", value: 8 },
    { source: "XRP", target: "USDT", value: 6 },
    { source: "ADA", target: "USDT", value: 5 },
    { source: "DOGE", target: "USDT", value: 4 }
  ]
};