import React from 'react';
import { Link } from 'react-router-dom';
import { Icons } from '../icons';
import Logo from '../brand/Logo';

export default function Sidebar() {
  return (
    <aside className="fixed left-0 top-0 h-screen w-60 bg-black border-r border-white/10">
      {/* Logo */}
      <div className="p-4">
        <Logo />
      </div>

      {/* Navigation Sections */}
      <nav className="mt-8 px-4 space-y-8">
        <div>
          <h3 className="text-xs font-swiss text-gray-500 uppercase mb-4">Platform</h3>
          <div className="space-y-2">
            <NavLink to="/chat" icon={<Icons.MessageSquare className="w-5 h-5" />} label="Chat" />
            <NavLink to="/docs" icon={<Icons.FileText className="w-5 h-5" />} label="Docs" />
          </div>
        </div>

        <div>
          <h3 className="text-xs font-swiss text-gray-500 uppercase mb-4">Agents</h3>
          <div className="space-y-2">
            <NavLink to="/market-agent" icon={<Icons.BarChart2 className="w-5 h-5" />} label="Market Agent" />
            <NavLink to="/trading-agent" icon={<Icons.TrendingUp className="w-5 h-5" />} label="Trading Agent" />
            <NavLink to="/social-agent" icon={<Icons.Users className="w-5 h-5" />} label="Social Agent" />
          </div>
        </div>
      </nav>
    </aside>
  );
}

interface NavLinkProps {
  to: string;
  icon: React.ReactNode;
  label: string;
}

function NavLink({ to, icon, label }: NavLinkProps) {
  return (
    <Link 
      to={to} 
      className="flex items-center space-x-3 text-white/80 hover:text-swiss-red p-2 rounded-lg transition-colors"
    >
      {icon}
      <span className="font-swiss">{label}</span>
    </Link>
  );
}