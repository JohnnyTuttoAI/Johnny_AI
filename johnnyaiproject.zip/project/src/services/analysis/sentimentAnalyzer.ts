export interface SentimentMetrics {
  funding: number;
  leverage: number;
  socialVolume: number;
  fearGreedIndex: number;
}

export class SentimentAnalyzer {
  private readonly weights = {
    funding: 0.3,
    leverage: 0.25,
    socialVolume: 0.2,
    fearGreedIndex: 0.25
  };

  analyzeSentiment(metrics: SentimentMetrics): {
    score: number;
    signals: string[];
  } {
    const score = this.calculateScore(metrics);
    const signals = this.interpretSignals(metrics);

    return { score, signals };
  }

  private calculateScore(metrics: SentimentMetrics): number {
    return (
      metrics.funding * this.weights.funding +
      metrics.leverage * this.weights.leverage +
      metrics.socialVolume * this.weights.socialVolume +
      metrics.fearGreedIndex * this.weights.fearGreedIndex
    );
  }

  private interpretSignals(metrics: SentimentMetrics): string[] {
    const signals: string[] = [];
    
    if (metrics.funding > 0.7) signals.push('High funding - potential reversal');
    if (metrics.leverage > 0.8) signals.push('Excessive leverage - liquidation risk');
    if (metrics.fearGreedIndex < 0.2) signals.push('Extreme fear - accumulation zone');
    
    return signals;
  }
}