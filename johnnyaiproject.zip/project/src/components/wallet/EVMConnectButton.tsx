import React from 'react';
import { ConnectButton as RainbowConnectButton } from '@rainbow-me/rainbowkit';
import { Icons } from '../icons';
import { WalletButtonContainer } from './WalletButtonContainer';
import { useWalletError } from '../../hooks/useWalletError';

export default function EVMConnectButton() {
  const { handleError } = useWalletError();

  return (
    <RainbowConnectButton.Custom>
      {({
        account,
        chain,
        openAccountModal,
        openChainModal,
        openConnectModal,
        mounted,
      }) => {
        const ready = mounted;
        const connected = ready && account && chain;

        if (!ready) return null;

        const handleConnect = async () => {
          try {
            await openConnectModal();
          } catch (error) {
            handleError(error);
          }
        };

        if (!connected) {
          return (
            <WalletButtonContainer onClick={handleConnect}>
              <Icons.Wallet className="w-4 h-4" />
              Connect EVM
            </WalletButtonContainer>
          );
        }

        if (chain.unsupported) {
          return (
            <WalletButtonContainer 
              onClick={openChainModal}
              variant="error"
            >
              Wrong Network
            </WalletButtonContainer>
          );
        }

        return (
          <div className="flex items-center gap-4">
            <WalletButtonContainer onClick={openChainModal}>
              {chain.hasIcon && chain.iconUrl && (
                <img
                  alt={chain.name ?? 'Chain icon'}
                  src={chain.iconUrl}
                  className="w-4 h-4"
                />
              )}
              {chain.name}
            </WalletButtonContainer>

            <WalletButtonContainer onClick={openAccountModal}>
              {account.displayName}
            </WalletButtonContainer>
          </div>
        );
      }}
    </RainbowConnectButton.Custom>
  );
}