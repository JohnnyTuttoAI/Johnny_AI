import { useState } from 'react';
import { ChatMessage } from '../types';
import { openAIService } from '../services/api/openai';
import { AI_IDENTITY } from '../config/constants';

export function useChat() {
  const [messages, setMessages] = useState<ChatMessage[]>([
    { 
      type: 'bot', 
      content: AI_IDENTITY.greeting
    }
  ]);
  const [isLoading, setIsLoading] = useState(false);

  const sendMessage = async (content: string) => {
    if (!content.trim()) return;

    setMessages(prev => [...prev, { type: 'user', content }]);
    setIsLoading(true);

    try {
      const response = await openAIService.getChatCompletion(content);
      setMessages(prev => [...prev, { type: 'bot', content: response }]);
    } catch (error) {
      setMessages(prev => [...prev, { 
        type: 'bot', 
        content: 'I encountered an error processing your request. Let\'s try a different approach.' 
      }]);
    } finally {
      setIsLoading(false);
    }
  };

  return {
    messages,
    isLoading,
    sendMessage
  };
}