import { 
  Bot, 
  Send, 
  User, 
  ExternalLink, 
  MessageSquare, 
  Twitter,
  BarChart2, 
  Wallet,
  Lock,
  FileText,
  Users,
  TrendingUp,
  Search
} from 'lucide-react';

export const Icons = {
  Bot,
  Send,
  User,
  ExternalLink,
  MessageSquare,
  Twitter,
  BarChart2,
  Wallet,
  Lock,
  FileText,
  Users,
  TrendingUp,
  Search
};