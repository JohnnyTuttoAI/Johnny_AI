export * from './marketStructure';
export * from './whaleTracking';
export * from './sentimentAnalyzer';
export * from './liquidityAnalyzer';

export interface AnalysisResult {
  marketStructure: MarketStructure;
  whaleActivity: WhaleActivity[];
  sentiment: {
    score: number;
    signals: string[];
  };
  liquidity: LiquidityMetrics;
}