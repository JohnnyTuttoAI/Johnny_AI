import React, { useEffect, useRef } from 'react';
import * as d3 from 'd3';
import { marketData } from './data';
import { Node, Link } from './types';
import { setupGradients } from './utils/gradients';
import { createSimulation } from './utils/simulation';

export default function NetworkGraph() {
  const svgRef = useRef<SVGSVGElement>(null);

  useEffect(() => {
    if (!svgRef.current) return;

    const svg = d3.select(svgRef.current);
    svg.selectAll("*").remove();

    const width = 600;
    const height = 600;
    
    // Setup gradients
    const defs = setupGradients(svg);

    // Create simulation
    const simulation = createSimulation(marketData.nodes, marketData.links, width, height);

    // Add background
    svg.append("circle")
      .attr("cx", width / 2)
      .attr("cy", height / 2)
      .attr("r", Math.min(width, height) / 2)
      .attr("fill", "url(#cyber-gradient)");

    // Create links
    const link = svg.append("g")
      .selectAll("line")
      .data(marketData.links)
      .join("line")
      .attr("stroke", "url(#link-gradient)")
      .attr("stroke-width", d => Math.sqrt(d.value || 1));

    // Create nodes
    const node = svg.append("g")
      .selectAll("circle")
      .data(marketData.nodes)
      .join("circle")
      .attr("r", d => d.value ? Math.sqrt(d.value) : 5)
      .attr("fill", d => {
        switch(d.group) {
          case "major": return "#00F0FF";
          case "stable": return "#00FF9F";
          case "exchange": return "#BD00FF";
          case "meme": return "#FF0099";
          default: return "#FFFFFF";
        }
      })
      .attr("stroke", "#000")
      .attr("stroke-width", 1.5);

    // Add labels
    const label = svg.append("g")
      .selectAll("text")
      .data(marketData.nodes)
      .join("text")
      .text(d => d.id)
      .attr("font-family", "var(--font-mono)")
      .attr("font-size", "10px")
      .attr("fill", "#FFFFFF")
      .attr("text-anchor", "middle")
      .attr("dy", "0.35em");

    // Update positions on simulation tick
    simulation.on("tick", () => {
      link
        .attr("x1", d => (d.source as Node).x || 0)
        .attr("y1", d => (d.source as Node).y || 0)
        .attr("x2", d => (d.target as Node).x || 0)
        .attr("y2", d => (d.target as Node).y || 0);

      node
        .attr("cx", d => d.x || 0)
        .attr("cy", d => d.y || 0);

      label
        .attr("x", d => d.x || 0)
        .attr("y", d => d.y || 0);
    });

    // Add zoom behavior
    svg.call(d3.zoom<SVGSVGElement, unknown>()
      .extent([[0, 0], [width, height]])
      .scaleExtent([0.5, 5])
      .on("zoom", ({transform}) => {
        link.attr("transform", transform);
        node.attr("transform", transform);
        label.attr("transform", transform);
      }));

    return () => {
      simulation.stop();
    };
  }, []);

  return (
    <div className="relative w-full aspect-square max-w-2xl mx-auto">
      <svg
        ref={svgRef}
        className="w-full h-full"
        viewBox="0 0 600 600"
        preserveAspectRatio="xMidYMid meet"
      />
      <div className="absolute inset-0 bg-grid-white/[0.02] pointer-events-none"></div>
    </div>
  );
}