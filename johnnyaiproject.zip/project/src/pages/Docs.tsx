import React from 'react';
import { Icons } from '../components/icons';

export default function Docs() {
  return (
    <div className="min-h-screen">
      {/* Page Header */}
      <header className="mb-12">
        <h1 className="text-4xl font-swiss mb-4">Documentation</h1>
        <p className="text-gray-400 font-mono">Technical specifications and integration guides</p>
      </header>

      {/* Documentation Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        <DocSection
          title="Market Analysis"
          description="Learn how to integrate with our market analysis endpoints and interpret the data."
          icon={<Icons.BarChart2 className="w-6 h-6" />}
          items={[
            "Real-time price feeds",
            "Order flow analysis",
            "Liquidity metrics",
            "Volume analysis"
          ]}
        />

        <DocSection
          title="Trading Integration"
          description="Documentation for trading agent integration and automated execution."
          icon={<Icons.TrendingUp className="w-6 h-6" />}
          items={[
            "Position management",
            "Risk parameters",
            "Execution strategies",
            "Performance tracking"
          ]}
        />

        <DocSection
          title="Social Sentiment"
          description="Access and analyze social sentiment data across platforms."
          icon={<Icons.Users className="w-6 h-6" />}
          items={[
            "Sentiment analysis",
            "Trend detection",
            "Influence metrics",
            "Network analysis"
          ]}
        />

        <DocSection
          title="Wallet Integration"
          description="Connect and interact with user wallets securely."
          icon={<Icons.Wallet className="w-6 h-6" />}
          items={[
            "Multi-chain support",
            "Transaction signing",
            "Balance tracking",
            "Security best practices"
          ]}
        />

        <DocSection
          title="API Reference"
          description="Complete API documentation with examples and use cases."
          icon={<Icons.FileText className="w-6 h-6" />}
          items={[
            "Authentication",
            "Endpoints",
            "Rate limits",
            "Response formats"
          ]}
        />

        <DocSection
          title="WebSocket Feeds"
          description="Real-time data streams for market and trading data."
          icon={<Icons.MessageSquare className="w-6 h-6" />}
          items={[
            "Connection handling",
            "Subscription topics",
            "Data formats",
            "Error handling"
          ]}
        />
      </div>
    </div>
  );
}

interface DocSectionProps {
  title: string;
  description: string;
  icon: React.ReactNode;
  items: string[];
}

function DocSection({ title, description, icon, items }: DocSectionProps) {
  return (
    <div className="group relative">
      {/* Swiss Border */}
      <div className="absolute inset-0 border border-swiss-red opacity-50 group-hover:opacity-100 transition-opacity"></div>
      
      {/* Content */}
      <div className="relative p-6 bg-black">
        {/* Header */}
        <div className="flex items-start space-x-4 mb-4">
          <div className="text-swiss-red group-hover:text-cyber-blue transition-colors">
            {icon}
          </div>
          <div>
            <h3 className="text-xl font-swiss mb-2">{title}</h3>
            <p className="text-sm text-gray-400 font-mono">{description}</p>
          </div>
        </div>

        {/* Items */}
        <ul className="space-y-2 mt-4">
          {items.map((item, index) => (
            <li key={index} className="flex items-center space-x-2 text-sm">
              <span className="w-1 h-1 bg-swiss-red"></span>
              <span className="font-mono text-gray-300">{item}</span>
            </li>
          ))}
        </ul>

        {/* Cyber Corner */}
        <div className="absolute top-0 right-0 w-2 h-2 bg-cyber-blue"></div>
      </div>
    </div>
  );
}