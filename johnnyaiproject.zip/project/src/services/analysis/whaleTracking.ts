interface WhaleActivity {
  address: string;
  type: 'accumulation' | 'distribution';
  volume: number;
  timestamp: number;
}

export class WhaleTracker {
  private readonly WHALE_THRESHOLD = 1000000; // $1M USD
  private readonly activities: WhaleActivity[] = [];

  trackActivity(address: string, volume: number): void {
    if (volume >= this.WHALE_THRESHOLD) {
      this.activities.push({
        address,
        type: this.determineActivityType(volume),
        volume,
        timestamp: Date.now()
      });
    }
  }

  getRecentActivity(timeWindow: number = 24 * 60 * 60 * 1000): WhaleActivity[] {
    const cutoff = Date.now() - timeWindow;
    return this.activities.filter(activity => activity.timestamp >= cutoff);
  }

  private determineActivityType(volume: number): 'accumulation' | 'distribution' {
    // Implement logic to determine if whale is accumulating or distributing
    return 'accumulation';
  }
}