import React from 'react';
import EVMConnectButton from './EVMConnectButton';
import SolanaConnectButton from './SolanaConnectButton';

export default function ConnectButton() {
  return (
    <div className="flex items-center space-x-4">
      <EVMConnectButton />
      <SolanaConnectButton />
    </div>
  );
}