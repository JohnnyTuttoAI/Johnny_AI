import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Icons } from '../components/icons';
import { useChat } from '../hooks/useChat';

export default function Landing() {
  const [input, setInput] = useState('');
  const { sendMessage } = useChat();
  const navigate = useNavigate();

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (input.trim()) {
      sendMessage(input);
      navigate('/chat');
    }
  };

  return (
    <div className="min-h-screen bg-black text-white">
      {/* Swiss Grid Background */}
      <div className="fixed inset-0 bg-swiss-grid opacity-5 pointer-events-none"></div>
      
      {/* Main Content */}
      <div className="min-h-screen flex flex-col items-center justify-center px-4">
        {/* Logo */}
        <div className="mb-8 relative w-24 h-24">
          <img
            src="https://i.ibb.co/SmnTg32/jkohnnny.png"
            alt="Johnny AI"
            className="w-full h-full object-cover border-2 border-swiss-red"
          />
          <div className="absolute inset-0 bg-gradient-to-r from-cyber-blue/10 to-cyber-purple/10 mix-blend-overlay"></div>
        </div>

        {/* Heading */}
        <div className="text-center mb-12">
          <h1 className="text-4xl font-swiss mb-2">
            How can <span className="text-swiss-red">Johnny</span> be of service?
          </h1>
          <p className="text-sm font-mono text-gray-400">
            Elite market intelligence powered by Swiss precision
          </p>
        </div>

        {/* Input Container */}
        <form onSubmit={handleSubmit} className="w-full max-w-2xl relative">
          <input
            type="text"
            value={input}
            onChange={(e) => setInput(e.target.value)}
            placeholder="Ask about market structure, institutional flows, or degen setups..."
            className="w-full bg-black/50 border-2 border-swiss-red text-white px-6 py-4 rounded-none font-mono text-sm focus:outline-none focus:border-cyber-blue transition-colors"
          />
          <button 
            type="submit"
            className="absolute right-4 top-1/2 -translate-y-1/2 text-swiss-red hover:text-cyber-blue transition-colors"
          >
            <Icons.Send className="w-5 h-5" />
          </button>
        </form>

        {/* Quick Actions */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mt-12 w-full max-w-2xl">
          <QuickAction
            icon={<Icons.BarChart2 className="w-5 h-5" />}
            label="Trending"
            sublabel="Search trending tokens"
            onClick={() => {
              sendMessage("Show me trending tokens");
              navigate('/chat');
            }}
          />
          <QuickAction
            icon={<Icons.Lock className="w-5 h-5" />}
            label="Stake"
            sublabel="Stake SOL for JupSOL"
            onClick={() => {
              sendMessage("How can I stake SOL for JupSOL?");
              navigate('/chat');
            }}
          />
          <QuickAction
            icon={<Icons.TrendingUp className="w-5 h-5" />}
            label="Trade"
            sublabel="Swap on Jupiter"
            onClick={() => {
              sendMessage("Show me how to trade on Jupiter");
              navigate('/chat');
            }}
          />
          <QuickAction
            icon={<Icons.Search className="w-5 h-5" />}
            label="Search X"
            sublabel="Query social media"
            onClick={() => {
              sendMessage("What's trending on crypto Twitter?");
              navigate('/chat');
            }}
          />
        </div>
      </div>
    </div>
  );
}

interface QuickActionProps {
  icon: React.ReactNode;
  label: string;
  sublabel: string;
  onClick: () => void;
}

function QuickAction({ icon, label, sublabel, onClick }: QuickActionProps) {
  return (
    <button 
      onClick={onClick}
      className="group bg-black/50 border border-white/10 p-4 hover:border-swiss-red transition-colors"
    >
      <div className="flex items-center space-x-3">
        <div className="text-swiss-red group-hover:text-cyber-blue transition-colors">
          {icon}
        </div>
        <div className="text-left">
          <div className="font-swiss text-sm">{label}</div>
          <div className="font-mono text-xs text-gray-500">{sublabel}</div>
        </div>
      </div>
    </button>
  );
}